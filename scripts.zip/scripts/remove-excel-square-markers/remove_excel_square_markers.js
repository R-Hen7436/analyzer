/*
remove_excel_square_markers.js

Remove ■ (U+25A0) from Excel workbook cells.

Default targets:
  EMD sheet    -> column C  (Affecting header/function)
  renEPC sheet -> column G  (Affecting header/function)

Run from the CodeAnalyzer project root so default paths resolve correctly.
*/

const fs = require("fs");
const path = require("path");
const ExcelJS = require("exceljs");
const JSZip = require("jszip");

const DEFAULT_INPUT = "./renEPC_change_point_list.xlsx";
const SHEET_COLUMNS = {
    EMD: [3],
    renEPC: [7]
};
const HISTORY_NAME = "History";
const HISTORY_TEMP = "_History_renamed_";
const SQUARE_RE = /■|\u25A0/g;

function cellText(value) {
    if (value === null || value === undefined) {
        return "";
    }

    if (typeof value === "object") {
        if (value.richText) {
            return value.richText.map((part) => part.text || "").join("");
        }

        if (value.text) {
            return String(value.text);
        }

        if (value.result !== undefined) {
            return String(value.result);
        }
    }

    return String(value);
}

function stripSquares(value) {
    if (value === null || value === undefined) {
        return { changed: false, value };
    }

    if (typeof value === "object" && value.richText) {
        let changed = false;
        const richText = value.richText.map((part) => {
            const nextText = String(part.text || "").replace(SQUARE_RE, "");

            if (nextText !== part.text) {
                changed = true;
            }

            return { ...part, text: nextText };
        });

        SQUARE_RE.lastIndex = 0;
        return {
            changed,
            value: changed ? { ...value, richText } : value
        };
    }

    const text = cellText(value);

    if (!SQUARE_RE.test(text)) {
        SQUARE_RE.lastIndex = 0;
        return { changed: false, value };
    }

    SQUARE_RE.lastIndex = 0;
    return {
        changed: true,
        value: text.replace(SQUARE_RE, "")
    };
}

async function renameHistoryInBuffer(buffer, fromName, toName) {
    const zip = await JSZip.loadAsync(buffer);
    const workbookFile = zip.file("xl/workbook.xml");

    if (!workbookFile) {
        throw new Error("xl/workbook.xml missing from workbook");
    }

    const xml = await workbookFile.async("string");
    const fromAttr = `name="${fromName}"`;
    const toAttr = `name="${toName}"`;

    if (!xml.includes(fromAttr)) {
        return buffer;
    }

    zip.file("xl/workbook.xml", xml.split(fromAttr).join(toAttr));

    return zip.generateAsync({
        type: "nodebuffer",
        compression: "DEFLATE"
    });
}

async function loadWorkbook(filePath) {
    const original = fs.readFileSync(filePath);
    const patched = await renameHistoryInBuffer(
        original,
        HISTORY_NAME,
        HISTORY_TEMP
    );
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(patched);
    return workbook;
}

async function saveWorkbook(workbook, outputPath) {
    const buffer = await workbook.xlsx.writeBuffer();
    const restored = await renameHistoryInBuffer(
        Buffer.from(buffer),
        HISTORY_TEMP,
        HISTORY_NAME
    );

    fs.writeFileSync(outputPath, restored);
}

function printHelp() {
    console.log(`Remove ■ from Excel workbook cells

Usage:
  node scripts/remove-excel-square-markers/remove_excel_square_markers.js [input.xlsx] [output.xlsx] [options]

Options (sheet scope — pick one):
  (default)       EMD + renEPC sheets, Affecting header/function columns only
  --emd           EMD sheet only (column C)
  --renepc        renEPC sheet only (column G)
  --all-sheets    Every worksheet in the workbook

Options (cell scope):
  --all-cells     Remove ■ from every cell on the selected sheet(s),
                  not just Affecting header/function columns

Other:
  --help, -h      Show this help

Examples:
  # Both EMD + renEPC (default), overwrite input with backup
  npm run strip-squares

  # EMD only
  npm run strip-squares:emd

  # renEPC only
  npm run strip-squares:renepc

  # Every sheet in the workbook
  npm run strip-squares:all-sheets

  # Write to a separate file
  node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx renEPC_change_point_list_cleaned.xlsx

  # renEPC only, all cells (includes section markers like ■UVP)
  node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx output.xlsx --renepc --all-cells

  # All sheets, all cells
  node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx output.xlsx --all-sheets --all-cells`);
}

function parseArgs(argv) {
    if (argv.includes("--help") || argv.includes("-h")) {
        return { help: true };
    }

    const flags = new Set(argv.filter((arg) => arg.startsWith("--")));
    const positional = argv.filter((arg) => !arg.startsWith("--"));

    const sheetFlags = ["--emd", "--renepc", "--all-sheets"].filter((flag) =>
        flags.has(flag)
    );

    if (sheetFlags.length > 1) {
        throw new Error(
            `Use only one sheet scope flag: ${sheetFlags.join(", ")}`
        );
    }

    let sheetScope = "both";
    if (flags.has("--emd")) sheetScope = "emd";
    if (flags.has("--renepc")) sheetScope = "renepc";
    if (flags.has("--all-sheets")) sheetScope = "all";

    return {
        help: false,
        inputPath: positional[0] || DEFAULT_INPUT,
        outputPath: positional[1] || positional[0] || DEFAULT_INPUT,
        sheetScope,
        allCells: flags.has("--all-cells")
    };
}

function columnsForSheet(sheetName, allCells) {
    if (allCells) {
        return null;
    }

    if (SHEET_COLUMNS[sheetName]) {
        return SHEET_COLUMNS[sheetName];
    }

    return null;
}

function resolveTargets(workbook, sheetScope) {
    if (sheetScope === "all") {
        return workbook.worksheets.map((sheet) => ({
            name: sheet.name,
            sheet
        }));
    }

    const sheetNames =
        sheetScope === "emd"
            ? ["EMD"]
            : sheetScope === "renepc"
              ? ["renEPC"]
              : ["EMD", "renEPC"];

    return sheetNames.map((name) => ({
        name,
        sheet: workbook.getWorksheet(name)
    }));
}

function processSheet(sheet, columns, allCells) {
    let changedCells = 0;
    const columnSet = columns ? new Set(columns) : null;

    sheet.eachRow({ includeEmpty: false }, (row) => {
        if (allCells || !columnSet) {
            row.eachCell({ includeEmpty: false }, (cell) => {
                const { changed, value } = stripSquares(cell.value);

                if (changed) {
                    cell.value = value;
                    changedCells += 1;
                }
            });
            return;
        }

        for (const colNumber of columnSet) {
            const cell = row.getCell(colNumber);
            const { changed, value } = stripSquares(cell.value);

            if (changed) {
                cell.value = value;
                changedCells += 1;
            }
        }
    });

    return changedCells;
}

function describeTarget(sheetName, columns, allCells) {
    if (allCells || !columns) {
        return "all cells";
    }

    return `column${columns.length > 1 ? "s" : ""} ${columns.join(", ")}`;
}

async function main() {
    const args = parseArgs(process.argv.slice(2));

    if (args.help) {
        printHelp();
        return;
    }

    const { inputPath, outputPath, sheetScope, allCells } = args;
    const resolvedInput = path.resolve(inputPath);
    const resolvedOutput = path.resolve(outputPath);

    if (!fs.existsSync(resolvedInput)) {
        throw new Error(
            `Input file not found: ${resolvedInput}\n` +
                `Run from the CodeAnalyzer folder and pass renEPC_change_point_list.xlsx\n` +
                `Run with --help for examples.`
        );
    }

    const workbook = await loadWorkbook(resolvedInput);
    const targets = resolveTargets(workbook, sheetScope);
    let totalChanged = 0;
    let sheetsProcessed = 0;

    for (const target of targets) {
        if (!target.sheet) {
            console.warn(`  Warning: sheet "${target.name}" not found, skipping`);
            continue;
        }

        const columns = columnsForSheet(target.name, allCells);
        const useAllCells = allCells || columns === null;
        const changed = processSheet(target.sheet, columns, useAllCells);
        totalChanged += changed;
        sheetsProcessed += 1;

        console.log(
            `  ${target.name} (${describeTarget(target.name, columns, useAllCells)}): ${changed} cell(s) updated`
        );
    }

    if (!sheetsProcessed) {
        throw new Error("No matching sheets were found to process.");
    }

    if (resolvedInput === resolvedOutput) {
        const backupPath = `${resolvedInput}.bak`;
        fs.copyFileSync(resolvedInput, backupPath);
        console.log(`Backup saved: ${backupPath}`);
    }

    await saveWorkbook(workbook, resolvedOutput);
    console.log(`Done. Removed ■ from ${totalChanged} cell(s).`);
    console.log(`Output: ${resolvedOutput}`);
}

main().catch((error) => {
    console.error(error.message || error);
    process.exit(1);
});
