# Remove Excel Square Markers

Removes **■** (`U+25A0`) from cells in `renEPC_change_point_list.xlsx` (or any `.xlsx` you pass).

Run all commands from the **CodeAnalyzer project root**:

```powershell
cd C:\Users\RHEN\Documents\CodeAnalyzer
```

## Sheet scope

| What you want | Command |
|---------------|---------|
| **EMD + renEPC** (default) | `npm run strip-squares` |
| **EMD only** (column C) | `npm run strip-squares:emd` |
| **renEPC only** (column G) | `npm run strip-squares:renepc` |
| **All worksheets** | `npm run strip-squares:all-sheets` |

### Node (same options)

```powershell
# Default: EMD + renEPC, Affecting header/function columns
node scripts/remove-excel-square-markers/remove_excel_square_markers.js

# EMD only
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --emd

# renEPC only
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --renepc

# Every sheet in the workbook
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --all-sheets
```

## Output file

By default the script reads and overwrites `renEPC_change_point_list.xlsx` and saves a backup as `renEPC_change_point_list.xlsx.bak`.

To write a separate file:

```powershell
node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx renEPC_change_point_list_cleaned.xlsx
```

Add a sheet flag as needed:

```powershell
node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx cleaned.xlsx --renepc
node scripts/remove-excel-square-markers/remove_excel_square_markers.js renEPC_change_point_list.xlsx cleaned.xlsx --all-sheets
```

## Column targets (default mode)

| Sheet | Column | Header |
|-------|--------|--------|
| EMD | C | Affecting header/function |
| renEPC | G | Affecting header/function |
| Other sheets (`--all-sheets`) | All cells | — |

## Remove ■ from every cell

Add `--all-cells` to also clean section markers (e.g. `■UVP` in column B):

```powershell
# Both sheets, all cells
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --all-cells

# renEPC only, all cells
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --renepc --all-cells

# Entire workbook, all cells
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --all-sheets --all-cells
```

## Help

```powershell
node scripts/remove-excel-square-markers/remove_excel_square_markers.js --help
```
